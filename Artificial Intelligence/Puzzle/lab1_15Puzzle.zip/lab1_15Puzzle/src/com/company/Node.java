package com.company;

import java.util.ArrayList;

/**
 * Created by student on 2/8/2017.
 */
public class Node {
    State s;
    ArrayList<String> actionList = new ArrayList<String>();



}
