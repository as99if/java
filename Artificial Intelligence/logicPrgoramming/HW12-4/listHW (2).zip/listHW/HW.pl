prefix(X, L) :- 
	append(X, _, L).
suffix(X, L) :- 
	append(_, X, L).
isin(X, L) :- 
	suffix(S, L), 
	prefix(X, S).