sumAB(A,A,A).
sumAB(A,B,C):-
	B>A,
	A1 is A+1,
	sumAB(A1,B,C1),
	C is A+c1.