package com.uchihaitachi;

import java.sql.*;

public class Main {
    static final String database = "jdbc:mysql://localhost/studentdb";
    static final String db_user = "root";
    static final String db_pass = "";
    static Connection conn;
    static Statement stmnt;

    public static void main(String[] args) {
        // write your code here
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(database, db_user, db_pass);

            stmnt = conn.createStatement();
            String query = "Select * FROM student";

            ResultSet rs = stmnt.executeQuery(query);

            while (rs.next()) {
                //Retrieve by column name

                String name = rs.getString("name");
                String id = rs.getString("id");
                String semester = rs.getString("semester");
                String dept = rs.getString("dept");


                //Display values
                System.out.print("ID: " + id);
                System.out.print(", Name: " + name);
                System.out.print(", Semester: " + semester);
                System.out.println(", Department: " + dept);
            }
            rs.close();
            stmnt.close();
            conn.close();

        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException se2) {
            }// nothing we can do
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
