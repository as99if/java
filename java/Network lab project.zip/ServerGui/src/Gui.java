
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.*;
import java.net.*;


public class Gui implements WindowListener, ActionListener, Runnable{
    public ServerSocket server;
	public Socket s1;
	public Frame f;
	public Button send,connect;
	public TextField tf;
	public TextArea ta;
	public InputStream is;
	public BufferedReader bf;
	public OutputStream os;
	public BufferedWriter br;
	public Gui(){
		f=new Frame("Server");
		send=new Button("send");
		connect=new Button("connect");
		tf=new TextField(20);
		ta=new TextArea(10,20);
	}
	
	public void show(){
		f.setSize(400,400);
		f.setLayout(new FlowLayout());
		send.setActionCommand("send");
		connect.setActionCommand("connect");
		send.addActionListener(this);
		connect.addActionListener(this);
		f.add(connect);
		f.add(tf);
		f.addWindowListener(this);
		f.add(send);
		f.add(ta);
		
		f.setVisible(true);
	}
	public void run()
        {
            String a;
		try {   
			
			is=s1.getInputStream();  // s1 theke input nibe
			bf=new BufferedReader(new InputStreamReader(is));
			a=bf.readLine();
			while (a!=null)
			{
			ta.append(a+"\n");
			a=bf.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
	
	public static void main(String[] args) {
		
		Gui a=new Gui();
		a.show();
		
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String ss=e.getActionCommand();
		if(ss.equals("connect")){
			try {
				server=new ServerSocket(3232);
				s1=server.accept();
				ta.setText("Connection Established\n");
				Thread b=new Thread(this);
				b.start();
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(ss.equals("send")){
			try {
				String a;
				os=s1.getOutputStream(); 		// s1 e likha pathabo
				br=new BufferedWriter(new OutputStreamWriter(os));
				a=tf.getText();
				br.write(a);
				br.newLine();
				br.flush();
				tf.setText(null);
			} catch (IOException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
		}
	}

	//@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		System.exit(0);
	}

	//@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


}

