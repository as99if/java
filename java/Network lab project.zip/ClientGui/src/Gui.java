
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.*;
import java.net.*;


public class Gui implements ActionListener, Runnable{
	public Socket s;
	public Frame f;
	public Button send,connect;
	public TextField tf;
	public TextArea ta;
	public OutputStream os;
	public BufferedWriter br;
	public InputStream is;
	public BufferedReader bf;
	
	public Gui(){
		f=new Frame("Client");
		send=new Button("send");
		connect=new Button("connect");
		tf=new TextField(20);
		ta=new TextArea(10,20);
	}
	
	public void show(){
		f.setSize(400,400);
		f.setLayout(new FlowLayout());
		send.setActionCommand("send");
		connect.setActionCommand("connect");
		send.addActionListener(this);
		connect.addActionListener(this);
		f.add(connect);
		f.add(tf);
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		f.add(send);
		f.add(ta);
		
		f.setVisible(true);
	}
	public void run()
        {
            String a;
		try {   
			
			is=s.getInputStream();
			bf=new BufferedReader(new InputStreamReader(is));
			a=bf.readLine();
			while (a!=null)
			{
			ta.append(a+"\n");
			a=bf.readLine();
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gui a=new Gui();
		a.show();	
		
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String ss=e.getActionCommand();
		if(ss.equals("connect")){
			try {
				
				s=new Socket("127.0.0.1",3232);
				Thread b=new Thread(this);
				b.start();
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(ss.equals("send")){
			try {
				String a;
				os=s.getOutputStream();
				br=new BufferedWriter(new OutputStreamWriter(os));
				a=tf.getText();
				br.write(a);
				br.newLine();
				br.flush();
				tf.setText(null);
				
			} catch (IOException ee) {
				// TODO Auto-generated catch block
				ee.printStackTrace();
			}
		}
	}



}

